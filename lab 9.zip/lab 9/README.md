# Course API

Simple Express + Mongoose API for managing courses.

## Setup

1. Copy `.env.example` to `.env` and set `MONGO_URI`.
2. Install dependencies:
   ```
   npm install
   ```
3. Start server:
   ```
   npm run start
   ```
   or for development with auto-reload:
   ```
   npm run dev
   ```

## Endpoints
- GET    /api/courses
- GET    /api/courses/:id
- POST   /api/courses
- PUT    /api/courses/:id
- DELETE /api/courses/:id
