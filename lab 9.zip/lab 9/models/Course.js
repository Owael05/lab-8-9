// models/Course.js
const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  instructor: { type: String, required: true },
  price: { type: Number, required: true, min: 0 },
  category: { type: String, required: true },
  enrolledStudents: { type: Number, default: 0, min: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Course', CourseSchema);
