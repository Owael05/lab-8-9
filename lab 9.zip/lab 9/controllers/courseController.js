// controllers/courseController.js
const Course = require('../models/Course');

exports.getAll = async (req, res, next) => {
  try {
    const courses = await Course.find();
    res.json(courses);
  } catch (err) { next(err); }
};

exports.getOne = async (req, res, next) => {
  try {
    const course = await Course.find(req.params.id);
    if (!course) return res.status(404).json({ error: 'Course not found' });
    res.json(course);
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    const { title, description, instructor, price, category, enrolledStudents } = req.body;
    const course = new Course({ title, description, instructor, price, category, enrolledStudents });
    const saved = await course.save();
    res.status(201).json(saved);
  } catch (err) { next(err); }
};

exports.update = async (req, res, next) => {
  try {
    const updated = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!updated) return res.status(404).json({ error: 'Course not found' });
    res.json(updated);
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    const removed = await Course.findByIdAndDelete(req.params.id);
    if (!removed) return res.status(404).json({ error: 'Course not found' });
    res.json({ message: 'Course deleted' });
  } catch (err) { next(err); }
};
