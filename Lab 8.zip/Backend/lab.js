const express = require("express");
const app = express();


app.use(express.json());

let posts = [];
let comments = {};


app.post("/posts", (req, res) => {

  const id = posts.length + 1;

  const post = {
    id,
    title: req.body["title"],
    content: req.body["content"],
  };

  posts.push(post);
  comments[id] = [];
  res.json(post);
});

app.get("/posts", (req, res) => {
  res.json(posts);
});

app.get("/posts/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const post = posts.find((p) => p.id === id);
  res.json(post);
});


app.post("/posts/:id/comments", (req, res) => {
  const id = parseInt(req.params.id);
  const comment = {
    text: req.body["text"],
  };
  comments[id].push(comment);
  res.json(comment);
});

app.get("/posts/:id/comments", (req, res) => {
  const id = parseInt(req.params.id);
  res.json(comments[id]);
});


app.listen(3000, () => {
  console.log(`Server running on port 3000`);
});
